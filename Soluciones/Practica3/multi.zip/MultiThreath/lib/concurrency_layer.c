#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "concurrency_layer.h"
#include <pthread.h>

#define ID_LENGTH 11
pthread_mutex_t mutex_queue;
pthread_mutex_t mutex_stocks;
pthread_cond_t not_full_queue;
pthread_cond_t not_empty_queue;
/*LA COLA ES DE LIMITE 10 OPERACIONES*/

void init_concurrency_mechanisms(){

       if(pthread_cond_init(&not_full_queue, NULL) != 0){
		perror("full queue  init failed");
	}
       if(pthread_cond_init(&not_empty_queue, NULL) !=0){
		perror("mutex empty_queue init failed");
	}
	if(pthread_mutex_init(&mutex_queue, NULL)!=0){
		perror("mutex_queue init failed");
	}

       if(pthread_mutex_init(&mutex_stocks, NULL)!=0){
                perror("mutex_stocks init failed");
        }
}

void destroy_concurrency_mechanisms(){
	if(pthread_cond_destroy(&not_full_queue) != 0){
		perror("full queue destroy failed");
	}
	if(pthread_cond_destroy(&not_empty_queue) != 0){
		perror("empty queue destroy failed");
	}
	int a;
	if((a = pthread_mutex_destroy(&mutex_queue)) != 0){
		perror("mutex_queue destruction failed ");
	}
        if(pthread_mutex_destroy(&mutex_stocks) != 0){
                perror("mutex_stocks destruction failed");
        }
}

void* broker(void * args) //Input = broker_info structure
{
        broker_info newBroker;
	memcpy(&newBroker,args,sizeof(broker_info));
	operation op;
        iterator * newIterator = new_iterator(newBroker.batch_file);
	if(newIterator == NULL){perror("El iterador ha dado fallo en BROKER");}
        while(next_operation(newIterator, op.id, &op.type, &op.num_shares, &op.share_price) > 0){
/*L queue*/	pthread_mutex_lock(&mutex_queue);
/*New Op*/      new_operation (&op, op.id, op.type, op.num_shares, op.share_price);
/*--------------Verificar si la cola está llena--------------------------------------*/
		if(operations_queue_full(newBroker.market -> stock_operations) == 1){
/*UL queue*/    	pthread_mutex_unlock(&mutex_queue);
/*SG not empty*/	pthread_cond_signal(&not_empty_queue);
/*W not_full, queue*/	pthread_cond_wait(&not_full_queue, &mutex_queue);
		}

/*--------------Encolo las operaciones en la cola del Market------------------------*/
    	        if(enqueue_operation(newBroker.market->stock_operations, &op) != 0){
                        perror("No se puede encolar en BROKER");
              	}
/*UL queue*/	pthread_mutex_unlock(&mutex_queue);
	}
/*SG not_empty*/pthread_cond_signal(&not_empty_queue);
	        destroy_iterator(newIterator);
		pthread_exit(0);
}

void* operation_executer(void * args)
{
        exec_info newExecutor;
	/*
        * int *exit
        * struct stock_market *market
        * pthread_mutex_t *exit_mutex
        */
        memcpy(&newExecutor,args,sizeof(exec_info));
	operation op;
	while(*newExecutor.exit != 1){
/*L Queue*/	pthread_mutex_lock(&mutex_queue);
/*--------------------Verificar si la cola está vacía-----------------------------*/
/*ColaEmpty*/	while(operations_queue_empty(newExecutor.market -> stock_operations) == 1){
/*W not_empty, queue*/	pthread_cond_wait(&not_empty_queue, &mutex_queue);
		}
/*-----------------------Empiezo a desencolar todo lo que tiene la cola--------------------------*/
/*L Stocks*/	pthread_mutex_lock(&mutex_stocks);
		while(operations_queue_empty(newExecutor.market -> stock_operations) != 1){
			if(dequeue_operation(newExecutor.market -> stock_operations, &op) >= 0){
					if(process_operation(newExecutor.market, &op) < 0){
						perror("------No se ha podido procesar la cola en operation_executer-------");
					}
			}else{
				perror("-------No se puede densencolar en operation_executer----------");
			}
		}
/*--------------------La cola ya está vacía-----------------------------------------------------*/
/*SG Printable*/ //pthread_cond_signal(&printable);
/*SG not_full*/	pthread_cond_signal(&not_full_queue);
/*UL Stocks*/	pthread_mutex_unlock(&mutex_stocks);
/*UL queue*/	pthread_mutex_unlock(&mutex_queue);
	}
	printf("----------------Valor de la Salida: %i\n", *newExecutor.exit);
	pthread_exit(0);
}

void* stats_reader(void * args)
{
        reader_info newReader_info;
	/*int *exit;
	* stock_market * market
	* pthread_mutex_t *exit_mutex;
	* unsigned int frequency;
	*/
	memcpy(&newReader_info,args,sizeof(reader_info));
	/*SECCION CRITICA*/
	while(*newReader_info.exit!=1){
/*L stocks*/	pthread_mutex_lock(&mutex_stocks);
/*W print,st*/	//pthread_cond_wait(&printable,&mutex_stocks);
/*------------------Imprimo las estadisiticas------------*/
		print_market_status(newReader_info.market);
/*UL Stocks*/   pthread_mutex_unlock(&mutex_stocks);
		usleep(newReader_info.frequency);
	}
		pthread_exit(0);
}
